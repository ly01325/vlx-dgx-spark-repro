# SPDX-FileCopyrightText: Copyright (c) 2025 - 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# Use of this software is governed by the terms and conditions of the
# NVIDIA End User License Agreement (EULA), available at:
# https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/license.html
#
# Any use, reproduction, disclosure, or distribution of this software
# and related documentation outside the scope permitted by the EULA
# is strictly prohibited.

import inspect
from typing import Any, Optional, Tuple, cast

import cutlass
from cutlass.cutlass_dsl import (
    Boolean,
    Integer,
    Int32,
    const_expr,
    extract_mlir_values,
    new_from_mlir_values,
    dsl_user_op,
)

from cutlass._mlir import ir
from cutlass.utils.mixed_cluster_params import MixedClusterParamsMixin
from cutlass.utils.static_persistent_tile_scheduler import (
    WorkTileInfo,
)
from typing_extensions import deprecated
import cutlass.cute as cute

_DEPRECATION_MSG = (
    "Migrated to examples/CuTeDSL/helpers/dynamic_persistent_tile_scheduler.py "
    "(BSD-3). The wheel copy will be removed in a future release."
)


@deprecated(_DEPRECATION_MSG)
class ClcDynamicPersistentTileSchedulerParams(MixedClusterParamsMixin):
    """A class to represent parameters for a dynamic persistent tile scheduler.

    This class is designed to manage and compute the layout of clusters and tiles
    in a batched gemm problem.

    :ivar cluster_shape_mn: Shape of the cluster in (m, n) dimensions (K dimension cta count must be 1).
    :type cluster_shape_mn: tuple
    """

    @dsl_user_op
    def __init__(
        self,
        problem_shape_ntile_mnl: cute.Shape,
        cluster_shape_mnk: cute.Shape,
        swizzle_size: int = 1,
        raster_along_m: bool = True,
        *,
        fallback_cluster_shape_mnk: Optional[cute.Shape] = None,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        """
        Initializes the ClcDynamicPersistentTileSchedulerParams with the given parameters.

        :param problem_shape_ntile_mnl: The shape of the problem in terms of
            number of CTA (Cooperative Thread Array) in (m, n, l) dimensions.
        :type problem_shape_ntile_mnl: cute.Shape
        :param cluster_shape_mnk: The shape of the cluster in (m, n) dimensions.
        :type cluster_shape_mnk: cute.Shape
        :param swizzle_size: Swizzling size in the unit of cluster. 1 means no swizzle
        :type swizzle_size: int
        :param raster_along_m: Rasterization order of clusters. Only used when swizzle_size > 1.
            True means along M, false means along N.
        :type raster_along_m: bool
        :param fallback_cluster_shape_mnk: Optional. When provided and
            different from cluster_shape_mnk, the kernel runs in mixed-cluster mode.
        :type fallback_cluster_shape_mnk: Optional[cute.Shape]

        :raises ValueError: If cluster_shape_k is not 1.
        """

        assert isinstance(cluster_shape_mnk, tuple)
        if cluster_shape_mnk[2] != 1:
            raise ValueError(f"unsupported cluster_shape_k {cluster_shape_mnk[2]}")
        if swizzle_size < 1:
            raise ValueError(f"expect swizzle_size >= 1, but get {swizzle_size}")

        self.problem_shape_ntile_mnl = problem_shape_ntile_mnl
        self._cluster_shape_mnk = cast(Tuple[int, int, int], tuple(cluster_shape_mnk))
        self.cluster_shape_mn = cluster_shape_mnk[:2]
        self.swizzle_size = swizzle_size
        self._raster_along_m = raster_along_m
        self.cluster_shape_major_fdd = None
        self.cluster_shape_minor_fdd = None
        self._loc = loc

        self._init_fallback(
            cast(Optional[Tuple[int, int, int]], fallback_cluster_shape_mnk),
            factory=lambda fb: ClcDynamicPersistentTileSchedulerParams(
                problem_shape_ntile_mnl,
                fb,
                swizzle_size,
                raster_along_m,
                fallback_cluster_shape_mnk=None,
                loc=loc,
                ip=ip,
            ),
        )

        # By default, we follow m major (col-major) raster order, so make a col-major layout
        self.problem_layout_ncluster_mnl = cute.make_layout(
            cute.ceil_div(
                self.problem_shape_ntile_mnl,
                cluster_shape_mnk[:2],
                loc=loc,
                ip=ip,
            ),
            loc=loc,
            ip=ip,
        )

        # Apply swizzle if swizzle_size > 1
        if swizzle_size > 1:
            problem_shape_ncluster_mnl = cute.round_up(
                self.problem_layout_ncluster_mnl.shape,
                (1, swizzle_size, 1) if raster_along_m else (swizzle_size, 1, 1),
            )
            assert isinstance(problem_shape_ncluster_mnl, tuple)

            if raster_along_m:
                self.problem_layout_ncluster_mnl = cute.make_layout(
                    (
                        problem_shape_ncluster_mnl[0],
                        (swizzle_size, problem_shape_ncluster_mnl[1] // swizzle_size),  # type: ignore[operator]
                        problem_shape_ncluster_mnl[2],
                    ),
                    stride=(
                        swizzle_size,
                        (1, swizzle_size * problem_shape_ncluster_mnl[0]),
                        problem_shape_ncluster_mnl[0] * problem_shape_ncluster_mnl[1],  # type: ignore[operator]
                    ),
                    loc=loc,
                    ip=ip,
                )
            else:
                self.problem_layout_ncluster_mnl = cute.make_layout(
                    (
                        (swizzle_size, problem_shape_ncluster_mnl[0] // swizzle_size),  # type: ignore[operator]
                        problem_shape_ncluster_mnl[1],
                        problem_shape_ncluster_mnl[2],
                    ),
                    stride=(
                        (1, swizzle_size * problem_shape_ncluster_mnl[1]),
                        swizzle_size,
                        problem_shape_ncluster_mnl[0] * problem_shape_ncluster_mnl[1],  # type: ignore[operator]
                    ),
                    loc=loc,
                    ip=ip,
                )
        elif not raster_along_m:
            cluster_count_major = self.problem_layout_ncluster_mnl.shape[1]
            cluster_count_minor = self.problem_layout_ncluster_mnl.shape[0]
            self.cluster_shape_major_fdd = cute.fast_divmod_create_divisor(
                cluster_count_major, loc=loc, ip=ip
            )
            self.cluster_shape_minor_fdd = cute.fast_divmod_create_divisor(
                cluster_count_minor, loc=loc, ip=ip
            )

    def _extract_primary_mlir_values(self) -> list[ir.Value]:
        # Caches ``_values_pos`` and ``_fastdivmod_indices`` for
        # ``_new_primary_from_mlir_values`` to decode the flat list.
        values: list[ir.Value] = []
        values_pos: list[int] = []
        for obj in [
            self.problem_shape_ntile_mnl,
            self._cluster_shape_mnk,
            self.swizzle_size,
            self._raster_along_m,
        ]:
            obj_values = extract_mlir_values(obj)
            values += obj_values
            values_pos.append(len(obj_values))

        # Add FastDivmod divisors to MLIR values for Host->Device transfer
        # Only add non-None values to avoid MLIR type errors
        fastdivmod_values = []
        fastdivmod_indices = []  # Track which FastDivmod objects are present

        for i, (_, fdd_obj) in enumerate(
            [
                ("cluster_shape_major_fdd", self.cluster_shape_major_fdd),
                ("cluster_shape_minor_fdd", self.cluster_shape_minor_fdd),
            ]
        ):
            if fdd_obj is not None:
                fdd_values = extract_mlir_values(fdd_obj)
                fastdivmod_values.extend(fdd_values)
                fastdivmod_indices.append(i)

        values += fastdivmod_values
        values_pos.append(
            len(fastdivmod_indices)
        )  # Store count of FastDivmod objects, not values

        self._values_pos = values_pos
        self._fastdivmod_indices = fastdivmod_indices
        return values

    @property
    def _primary_values_count(self) -> int:
        return sum(self._values_pos[:-1]) + len(self._fastdivmod_indices)

    def _new_primary_from_mlir_values(
        self, values: list[ir.Value]
    ) -> "ClcDynamicPersistentTileSchedulerParams":
        obj_list = []
        values_copy = list(values)
        for obj, n_items in zip(
            [
                self.problem_shape_ntile_mnl,
                self._cluster_shape_mnk,
                self.swizzle_size,
                self._raster_along_m,
            ],
            self._values_pos[:-1],  # Exclude FastDivmod count
        ):
            obj_list.append(new_from_mlir_values(obj, values_copy[:n_items]))
            values_copy = values_copy[n_items:]

        new_params = ClcDynamicPersistentTileSchedulerParams(
            *(tuple(obj_list)), loc=self._loc
        )

        # Restore FastDivmod divisors from remaining values
        fdd_names = [
            "cluster_shape_major_fdd",
            "cluster_shape_minor_fdd",
        ]
        if len(self._fastdivmod_indices) > 0:
            for j, original_index in enumerate(self._fastdivmod_indices):
                fdd_name = fdd_names[original_index]
                original_fdd = getattr(self, fdd_name)
                if original_fdd is not None and j < len(values_copy):
                    reconstructed_fdd = new_from_mlir_values(
                        original_fdd, [values_copy[j]]
                    )
                    setattr(new_params, fdd_name, reconstructed_fdd)
        return new_params

    @dsl_user_op
    def get_grid_shape(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> Tuple[Integer, Integer, Integer]:
        """
        Computes the grid shape based on the problem shape and cluster shape.

        :return: the grid is the CTA numbers that has aligned with cluster shape.
        """

        problem_ceiling_cta_mnl = cute.round_up(
            self.problem_shape_ntile_mnl, self._cluster_shape_mnk
        )

        if self.swizzle_size == 1 and self._raster_along_m:
            return problem_ceiling_cta_mnl  # type: ignore[return-value]
        else:
            # If swizzling is enabled or raster_along_n,
            # we are going to map from a linear idx to tile id manually.
            num_problem_cta_count = cute.size(problem_ceiling_cta_mnl, loc=loc, ip=ip)
            num_ctas_per_cluster = cute.size(self.cluster_shape_mn, loc=loc, ip=ip)
            return (
                *self.cluster_shape_mn,
                num_problem_cta_count // num_ctas_per_cluster,
            )


# Set explicit signature for Sphinx documentation to avoid issues with @dsl_user_op decorator
ClcDynamicPersistentTileSchedulerParams.__init__.__signature__ = inspect.Signature(  # type: ignore[attr-defined]
    [
        inspect.Parameter("self", inspect.Parameter.POSITIONAL_OR_KEYWORD),
    ]
)


@deprecated(_DEPRECATION_MSG)
class ClcDynamicPersistentTileScheduler:
    """A scheduler for dynamic persistent tile execution in CUTLASS/CuTe kernels.

    :ivar params: Tile schedule related params, including cluster shape.
    :type params: ClcDynamicPersistentTileSchedulerParams
    :ivar cta_id_in_cluster: ID of the CTA within its cluster
    :type cta_id_in_cluster: cute.Coord
    :ivar _num_tiles_executed: Counter for executed tiles
    :type _num_tiles_executed: Int32
    """

    def __init__(
        self,
        params: ClcDynamicPersistentTileSchedulerParams,
        cta_id_in_cluster: cute.Coord,
        num_tiles_executed: Int32,
        clc_response_ptr: cute.Pointer,
        block_idx: Tuple[Integer, Integer, Integer],
        insert_fence: bool = True,
    ):
        """
        Initializes the ClcDynamicPersistentTileScheduler with the given parameters.

        :param params: Tile schedule related params, including cluster shape.
        :type params: ClcDynamicPersistentTileSchedulerParams
        :param cta_id_in_cluster: ID of the CTA within its cluster.
        :type cta_id_in_cluster: cute.Coord
        :param num_tiles_executed: Counter for executed tiles.
        :type num_tiles_executed: Int32
        :param clc_response_ptr: Pointer of the clc rsponse.
        :type clc_response_ptr: cute.Pointer
        :param block_idx: The block index.
        :type block_idx: Tuple[Integer, Integer, Integer]
        :param insert_fence: Whether to insert a fence to ensure generic-async proxy order.
            CLC issue is in async proxy while loading the response from shared memory is in
            generic proxy. A cross-proxy fence is needed to ensure producer's next issue
            won't race with consumer's current loading. Therefore the scheduler inserts a
            fence by default after loading the response.
            Developers may insert the fence in pipeline acquire/release functions. In that case,
            the fence here can be omitted.
        :type insert_fence: bool
        """
        self.params = params
        self.cta_id_in_cluster = cta_id_in_cluster
        self._num_tiles_executed = num_tiles_executed
        self._clc_response_ptr = clc_response_ptr
        self._block_idx = block_idx
        self.insert_fence = insert_fence

    def __extract_mlir_values__(self) -> list[ir.Value]:
        values = extract_mlir_values(self.cta_id_in_cluster)
        values.extend(extract_mlir_values(self._num_tiles_executed))
        values.extend(extract_mlir_values(self._clc_response_ptr))
        values.extend(extract_mlir_values(self._block_idx))
        return values

    def __new_from_mlir_values__(
        self, values: list[ir.Value]
    ) -> "ClcDynamicPersistentTileScheduler":
        assert len(values) == 8
        new_cta_id_in_cluster = new_from_mlir_values(
            self.cta_id_in_cluster, values[0:3]
        )
        new_num_tiles_executed = new_from_mlir_values(
            self._num_tiles_executed, [values[3]]
        )
        new_clc_response_ptr = new_from_mlir_values(self._clc_response_ptr, [values[4]])
        new_block_idx = new_from_mlir_values(self._block_idx, values[5:8])
        return ClcDynamicPersistentTileScheduler(
            self.params,
            new_cta_id_in_cluster,
            new_num_tiles_executed,
            new_clc_response_ptr,
            new_block_idx,
        )

    @dsl_user_op
    @staticmethod
    def create(
        params: ClcDynamicPersistentTileSchedulerParams,
        block_idx: Tuple[Integer, Integer, Integer],
        grid_dim: Tuple[Integer, Integer, Integer],
        clc_response_ptr: cute.Pointer,
        insert_fence: bool = True,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> "ClcDynamicPersistentTileScheduler":
        """Initialize the dynamic persistent tile scheduler.

        :param params: Parameters for the persistent
            tile scheduler.
        :type params: ClcDynamicPersistentTileSchedulerParams
        :param block_idx: The 3d block index in the format (bidx, bidy, bidz).
        :type block_idx: Tuple[Integer, Integer, Integer]
        :param grid_dim: The 3d grid dimensions for kernel launch.
        :type grid_dim: Tuple[Integer, Integer, Integer]

        :return: A ClcDynamicPersistentTileScheduler object.
        :rtype: ClcDynamicPersistentTileScheduler
        """
        if const_expr(params._has_distinct_fallback):
            active = params._select_active_params(params)
        else:
            active = params

        bidx, bidy, bidz = block_idx

        # Mixed-cluster: use runtime cluster dims (see ``MixedClusterParamsMixin``).
        if const_expr(params._has_distinct_fallback):
            cdx, cdy, _ = params.runtime_cluster_dims()
            cta_id_in_cluster = (
                Int32(bidx % cdx),
                Int32(bidy % cdy),
                Int32(0),
            )
        else:
            cta_id_in_cluster = (
                Int32(bidx % active.cluster_shape_mn[0]),
                Int32(bidy % active.cluster_shape_mn[1]),
                Int32(0),
            )

        # Initialize number of tiles executed to zero
        num_tiles_executed = Int32(0)
        # Initialize clc response pointer
        clc_response_ptr = clc_response_ptr
        # The block index
        block_idx = block_idx

        return ClcDynamicPersistentTileScheduler(
            active,
            cta_id_in_cluster,
            num_tiles_executed,
            clc_response_ptr,
            block_idx,
            insert_fence,
        )

    # called by host
    @dsl_user_op
    def get_grid_shape(
        params: ClcDynamicPersistentTileSchedulerParams,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> Tuple[Integer, Integer, Integer]:
        """Calculates the grid shape to be launched on GPU using problem shape,
        threadblock shape, and active cluster size.

        :param params: Parameters for grid shape calculation.
        :type params: ClcDynamicPersistentTileSchedulerParams

        :return: The calculated 3d grid shape.
        :rtype: Tuple[Integer, Integer, Integer]
        """

        return params.get_grid_shape(loc=loc, ip=ip)

    @cute.jit
    def _swizzle_and_rasterize(
        self,
        x_idx: Int32,
        y_idx: Int32,
        z_idx: Int32,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> Tuple[Int32, Int32, Int32]:
        """Swizzle and rasterize the given coordinates for leader CTA of the cluster.
        x_idx, y_idx, and z_idx must be divisible by cluster shape x, y, and z respectively. They should not be offset
        by the ID of the CTA in the cluster.
        """
        # Mixed-cluster: use runtime cluster dims (see ``MixedClusterParamsMixin``).
        if cutlass.const_expr(self.params._has_distinct_fallback):
            cdx, cdy, _ = self.params.runtime_cluster_dims()
            cluster_shape_m: Any = cdx
            cluster_shape_n: Any = cdy
        else:
            cluster_shape_m = self.params.cluster_shape_mn[0]
            cluster_shape_n = self.params.cluster_shape_mn[1]

        if cutlass.const_expr(self.params.swizzle_size == 1):
            if cutlass.const_expr(self.params._raster_along_m):
                return x_idx, y_idx, z_idx
            else:
                # Decode linear index using FastDivmod objects.
                # First, get cluster_major using cluster_shape_major_fdd
                cluster_minor_batch, cluster_major = divmod(  # type: ignore[operator]
                    z_idx, self.params.cluster_shape_major_fdd
                )
                # Then decode cluster_minor_batch to get cluster_minor and batch_l using FastDivmod
                batch_l, cluster_minor = divmod(
                    cluster_minor_batch, self.params.cluster_shape_minor_fdd
                )
                cluster_m = cluster_minor
                cluster_n = cluster_major

                return (
                    cluster_m * cluster_shape_m,
                    cluster_n * cluster_shape_n,
                    batch_l,
                )
        else:
            cluster_coord = self.params.problem_layout_ncluster_mnl.get_flat_coord(
                z_idx, loc=loc, ip=ip
            )
            return (
                cluster_coord[0] * cluster_shape_m,
                cluster_coord[1] * cluster_shape_n,
                cluster_coord[2],
            )

    @dsl_user_op
    def work_tile_info_from_clc_response(
        self,
        result_addr: cute.Pointer,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> WorkTileInfo:
        """
        Simulates parsing CLC response data in Python.
        result_addr: 16-byte response data (simulating shared memory access)
        """
        m_idx, n_idx, l_idx, vld = cute.arch.clc_response(result_addr, loc=loc, ip=ip)

        # Cross-proxy fence to ensure generic proxy access are seen by later
        # async proxy operations.
        if self.insert_fence:
            cute.arch.fence_proxy("async.shared", space="cta", loc=loc, ip=ip)

        m_idx, n_idx, l_idx = self._swizzle_and_rasterize(
            m_idx, n_idx, l_idx, loc=loc, ip=ip
        )
        cta_idx_in_cluster, cta_idy_in_cluster, _ = self.cta_id_in_cluster  # type: ignore[misc]
        cur_tile_coord = (m_idx + cta_idx_in_cluster, n_idx + cta_idy_in_cluster, l_idx)

        return WorkTileInfo(cur_tile_coord, vld)

    @dsl_user_op
    @cute.jit
    def get_current_work(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> WorkTileInfo:
        smem_addr = self._clc_response_ptr
        work_tile = self.work_tile_info_from_clc_response(smem_addr, loc=loc, ip=ip)
        return work_tile

    @dsl_user_op
    @cute.jit
    def initial_work_tile_info(
        self, *, loc: Any = None, ip: Any = None
    ) -> WorkTileInfo:
        bidx, bidy, bidz = self._block_idx
        # Subtract cta_id_in_cluster from block_idx because swizzle_and_rasterize expects coordinates to be
        # those of the leader CTA in the cluster.
        cta_idx_in_cluster, cta_idy_in_cluster, _ = self.cta_id_in_cluster  # type: ignore[misc]
        m_idx = bidx - cta_idx_in_cluster
        n_idx = bidy - cta_idy_in_cluster
        l_idx = bidz
        m_idx, n_idx, l_idx = self._swizzle_and_rasterize(
            m_idx, n_idx, l_idx, loc=loc, ip=ip
        )
        cur_tile_coord = (m_idx + cta_idx_in_cluster, n_idx + cta_idy_in_cluster, l_idx)
        return WorkTileInfo(cur_tile_coord, Boolean(True))

    @dsl_user_op
    @cute.jit
    def advance_to_next_work(
        self,
        mbarrier_addr: cute.Pointer,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        # Query new work tile
        with cute.arch.elect_one():
            cute.arch.issue_clc_query(
                mbarrier_addr, self._clc_response_ptr, loc=loc, ip=ip
            )
        self._num_tiles_executed += Int32(1)

    @property
    @cute.jit
    def num_tiles_executed(self) -> Int32:
        return self._num_tiles_executed
