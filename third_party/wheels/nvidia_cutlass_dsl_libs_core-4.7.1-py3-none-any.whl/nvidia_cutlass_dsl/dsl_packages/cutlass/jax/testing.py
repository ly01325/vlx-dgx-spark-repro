# SPDX-FileCopyrightText: Copyright (c) 2025 - 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# Use of this software is governed by the terms and conditions of the
# NVIDIA End User License Agreement (EULA), available at:
# https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/license.html
#
# Any use, reproduction, disclosure, or distribution of this software
# and related documentation outside the scope permitted by the EULA
# is strictly prohibited.

import jax
import jax.numpy as jnp

from typing import Sequence

import cutlass.cute as cute
from cutlass.cutlass_dsl import dsl_user_op
from cutlass._mlir import ir


def reorder_modes(src: Sequence[str], target: Sequence[str]) -> tuple[int, ...]:
    """Compute a ``TensorSpec.mode`` from physical input order to kernel order.

    ``src`` names the JAX array's physical dimension order. ``target`` names the
    logical mode order that the CuTe kernel expects. The returned tuple can be
    passed as ``TensorSpec(mode=...)`` while leaving ``layout`` at its default
    row-major value when the JAX buffer is physically row-major.
    """
    src = tuple(src)
    target = tuple(target)
    src_map = {}
    for idx, s in enumerate(src):
        src_map[s] = idx
    return tuple([src_map[d] for d in target])


def gemm_a_major(d: str) -> str:
    """Return the physical JAX dimension order for an A tensor major mode.

    The returned string is not the kernel's canonical logical order. Use
    :func:`gemm_a_mode` to map this physical order to kernel logical ``mkl``.
    """
    return {"k": "lmk", "m": "lkm"}[d]


def gemm_a_mode(d: str) -> tuple[int, ...]:
    """Return ``TensorSpec.mode`` for A, mapping physical order to logical ``mkl``."""
    return reorder_modes(gemm_a_major(d), "mkl")


def gemm_b_major(d: str) -> str:
    """Return the physical JAX dimension order for a B tensor major mode.

    The returned string is not the kernel's canonical logical order. Use
    :func:`gemm_b_mode` to map this physical order to kernel logical ``nkl``.
    """
    return {"k": "lnk", "n": "lkn"}[d]


def gemm_b_mode(d: str) -> tuple[int, ...]:
    """Return ``TensorSpec.mode`` for B, mapping physical order to logical ``nkl``."""
    return reorder_modes(gemm_b_major(d), "nkl")


def gemm_c_major(d: str) -> str:
    """Return the physical JAX dimension order for a C/D tensor major mode.

    The returned string is not the kernel's canonical logical order. Use
    :func:`gemm_c_mode` to map this physical order to kernel logical ``mnl``.
    """
    return {"n": "lmn", "m": "lnm"}[d]


def gemm_c_mode(d: str) -> tuple[int, ...]:
    """Return ``TensorSpec.mode`` for C/D, mapping physical order to logical ``mnl``."""
    return reorder_modes(gemm_c_major(d), "mnl")


def gemm_a_shape(l: int, m: int, k: int, major: str) -> tuple[int, ...]:
    """Return the physical row-major JAX shape for A with the requested major mode."""
    assert major in ("k", "m")
    shape = (l, m, k) if major == "k" else (l, k, m)
    return shape


def gemm_b_shape(l: int, n: int, k: int, major: str) -> tuple[int, ...]:
    """Return the physical row-major JAX shape for B with the requested major mode."""
    assert major in ("k", "n")
    shape = (l, n, k) if major == "k" else (l, k, n)
    return shape


def gemm_c_shape(l: int, m: int, n: int, major: str) -> tuple[int, ...]:
    """Return the physical row-major JAX shape for C/D with the requested major mode."""
    assert major in ("m", "n")
    shape = (l, m, n) if major == "n" else (l, n, m)
    return shape


@dsl_user_op
def get_gemm_shape_from_tensors(
    a: cute.Tensor,
    b: cute.Tensor,
    *,
    loc: ir.Location | None = None,
    ip: ir.InsertionPoint | None = None,
) -> tuple[int, int, int, int]:
    """Returns a tuple of (M, N, K, L) from A/B gemm tensors."""
    # mkl, nkl
    a_shape = a.shape
    b_shape = b.shape
    assert isinstance(a_shape, tuple)
    assert isinstance(b_shape, tuple)
    m, k, l = a_shape[:]
    n = b_shape[0]
    return (m, n, k, l)  # type: ignore[return-value]


def create_tensor(
    shape: tuple[int, ...],
    dtype: jnp.dtype,
    key: jax.Array,
    *,
    minval: float = -2.0,
    maxval: float = 2.0,
    fill_value: float | int | None = None,
    fill_arange: bool = False,
) -> jax.Array:
    if fill_arange:
        tensor = jnp.ones(shape, dtype=dtype)
        tensor = tensor * jnp.arange(tensor.size, dtype=tensor.dtype).reshape(
            tensor.shape
        )
    elif fill_value is not None:
        tensor = jnp.full(shape, fill_value, dtype=dtype)
    else:
        tensor = jax.random.uniform(
            key, shape, dtype=jnp.float32, minval=minval, maxval=maxval
        )
        tensor = tensor.astype(dtype)
    return tensor


def create_a_tensor(
    l: int,
    m: int,
    k: int,
    major: str,
    dtype: jnp.dtype,
    key: jax.Array,
    minval: float = -2.0,
    maxval: float = 2.0,
    fill_value: float | int | None = None,
    fill_arange: bool = False,
) -> jax.Array:
    shape = gemm_a_shape(l, m, k, major)
    tensor = create_tensor(
        shape,
        dtype,
        key,
        minval=minval,
        maxval=maxval,
        fill_value=fill_value,
        fill_arange=fill_arange,
    )
    return tensor


def create_b_tensor(
    l: int,
    n: int,
    k: int,
    major: str,
    dtype: jnp.dtype,
    key: jax.Array,
    minval: float = -2.0,
    maxval: float = 2.0,
    fill_value: float | int | None = None,
    fill_arange: bool = False,
) -> jax.Array:
    shape = gemm_b_shape(l, n, k, major)
    tensor = create_tensor(
        shape,
        dtype,
        key,
        minval=minval,
        maxval=maxval,
        fill_value=fill_value,
        fill_arange=fill_arange,
    )
    return tensor


def create_cd_tensor(
    l: int,
    m: int,
    n: int,
    major: str,
    dtype: jnp.dtype,
    key: jax.Array,
    *,
    minval: float = -2.0,
    maxval: float = 2.0,
    fill_value: float | int | None = None,
    fill_arange: bool = False,
) -> jax.Array:
    shape = gemm_c_shape(l, m, n, major)
    tensor = create_tensor(
        shape,
        dtype,
        key,
        minval=minval,
        maxval=maxval,
        fill_value=fill_value,
        fill_arange=fill_arange,
    )
    return tensor


def gemm_reference_einsum(
    a: jax.Array,
    b: jax.Array,
    acc_dtype: jnp.dtype,
    c_dtype: jnp.dtype,
    a_major: str,
    b_major: str,
    c_major: str,
    sf_a: jax.Array | None = None,
    sf_b: jax.Array | None = None,
    precision: str = "highest",
) -> jax.Array:
    a_idx = gemm_a_major(a_major)
    b_idx = gemm_b_major(b_major)
    c_idx = gemm_c_major(c_major)
    spec = f"{a_idx},{b_idx}->{c_idx}"

    # If block scaled pre-scale input at higher precision
    # Assumes we only use it for fp8 and smaller.
    if sf_a is not None:
        sf_vec_size = int(a.shape[-1] // sf_a.shape[-1])
        sf_a = jnp.repeat(sf_a, sf_vec_size, axis=-1)
        a = a.astype(jnp.float16) * sf_a.astype(jnp.float16)

    if sf_b is not None:
        sf_vec_size = int(b.shape[-1] // sf_b.shape[-1])
        sf_b = jnp.repeat(sf_b, sf_vec_size, axis=-1)
        b = b.astype(jnp.float16) * sf_b.astype(jnp.float16)

    return jax.jit(
        lambda a, b: jnp.einsum(
            spec, a, b, preferred_element_type=acc_dtype, precision=precision
        ).astype(c_dtype)
    )(a, b)


def create_attn_tensors(
    b: int,
    s: int,
    hq: int,
    hkv: int,
    d: int,
    dtype: jnp.dtype,
    key: jax.Array,
    *,
    minval: float = -2.0,
    maxval: float = 2.0,
    fill_value: float | int | None = None,
) -> tuple[jax.Array, jax.Array, jax.Array]:
    qkey, kkey, vkey = jax.random.split(key, 3)
    return (
        create_tensor(
            (b, s, hq, d),
            dtype,
            qkey,
            minval=minval,
            maxval=maxval,
            fill_value=fill_value,
        ),
        create_tensor(
            (b, s, hkv, d),
            dtype,
            kkey,
            minval=minval,
            maxval=maxval,
            fill_value=fill_value,
        ),
        create_tensor(
            (b, s, hkv, d),
            dtype,
            vkey,
            minval=minval,
            maxval=maxval,
            fill_value=fill_value,
        ),
    )


def attn_ref(q: jax.Array, k: jax.Array, v: jax.Array, is_causal: bool) -> jax.Array:
    return jax.jit(
        lambda q, k, v: jax.nn.dot_product_attention(
            q, k, v, is_causal=is_causal, implementation="cudnn"
        )
    )(q, k, v)
