# SPDX-FileCopyrightText: Copyright (c) 2025 - 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# Use of this software is governed by the terms and conditions of the
# NVIDIA End User License Agreement (EULA), available at:
# https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/license.html
#
# Any use, reproduction, disclosure, or distribution of this software
# and related documentation outside the scope permitted by the EULA
# is strictly prohibited.

from dataclasses import dataclass
from typing import Any, Literal, Optional, cast

import cutlass.cute as cute
from cutlass._mlir import ir
from cutlass.cute.arch.constants import (
    WARP_SIZE,
)
from cutlass.cute.core import is_static
from cutlass.cutlass_dsl import Boolean, Int32, if_generate, dsl_user_op

from cutlass.pipeline import (
    Agent,
    CooperativeGroup,
    MbarrierArray,
    PipelineOp,
    PipelineState,
    PipelineUserType,
    SyncObject,
    TmaStoreFence,
    alloc_reserved_mbarrier,
    make_pipeline_state,
    agent_sync,
)
from cutlass.pipeline.helpers import _get_thread_arrive_count
from cutlass.pipeline.profiling import register_barrier

##############################################################################
# Pipeline classes
##############################################################################


@dataclass(frozen=True)
class PipelineAsync:
    """PipelineAsync is a generic pipeline class where both the producer and consumer are
    AsyncThreads. It also serves as a base class for specialized pipeline classes.

    This class implements a producer-consumer pipeline pattern where both sides operate
    asynchronously. The pipeline maintains synchronization state using barrier objects
    to coordinate between producer and consumer threads.

    The pipeline state transitions of one pipeline entry(mbarrier) can be represented as:

    .. table:: Pipeline State Transitions
       :widths: auto

       +-----------+-----------+-----------+-----------+-----------+-----------+
       | Barrier   | State     | p.acquire | p.commit  | c.wait    | c.release |
       +===========+===========+===========+===========+===========+===========+
       | empty_bar | empty     | <Return>  | n/a       | n/a       | -         |
       +-----------+-----------+-----------+-----------+-----------+-----------+
       | empty_bar | wait      | <Block>   | n/a       | n/a       | -> empty  |
       +-----------+-----------+-----------+-----------+-----------+-----------+
       | full_bar  | wait      | n/a       | -> full   | <Block >  | n/a       |
       +-----------+-----------+-----------+-----------+-----------+-----------+
       | full_bar  | full      | n/a       | -         | <Return>  | n/a       |
       +-----------+-----------+-----------+-----------+-----------+-----------+

    Where:

    - p: producer
    - c: consumer
    - <Block>: This action is blocked until transition to a state allow it to proceed by other side
      - e.g. ``p.acquire()`` is blocked until ``empty_bar`` transition to ``empty`` state by ``c.release()``

    .. code-block:: text

        Array of mbarriers as circular buffer:

             Advance Direction
           <-------------------

            Producer   Consumer
                |         ^
                V         |
           +-----------------+
         --|X|X|W|D|D|D|D|R|X|<-.
        /  +-----------------+   \\
        |                        |
        `------------------------'

    Where:

    - X: Empty buffer (initial state)
    - W: Producer writing (producer is waiting for buffer to be empty)
    - D: Data ready (producer has written data to buffer)
    - R: Consumer reading (consumer is consuming data from buffer)

    **Example:**

    .. code-block:: python

        # Create pipeline with 5 stages
        pipeline = PipelineAsync.create(
            num_stages=5,                   # number of pipeline stages
            producer_group=producer_warp,
            consumer_group=consumer_warp
            barrier_storage=smem_ptr,       # smem pointer for array of mbarriers in shared memory
        )

        producer, consumer = pipeline.make_participants()
        # Producer side
        for i in range(num_iterations):
            handle = producer.acquire_and_advance()  # Wait for buffer to be empty & Move index to next stage
            # Write data to pipeline buffer
            handle.commit()   # Signal buffer is full

        # Consumer side
        for i in range(num_iterations):
            handle = consumer.wait_and_advance()     # Wait for buffer to be full & Move index to next stage
            # Read data from pipeline buffer
            handle.release()  # Signal buffer is empty
    """

    sync_object_full: SyncObject
    sync_object_empty: SyncObject
    num_stages: int
    producer_mask: Optional[Int32]
    consumer_mask: Optional[Int32]

    @staticmethod
    def _make_sync_object(
        barrier_storage: cute.Pointer,
        num_stages: int,
        agent: tuple[PipelineOp, CooperativeGroup],
        tx_count: int = 0,
        name: str = "",
        phase: Literal["", "full", "empty"] = "",
    ) -> SyncObject:
        """
        Returns a SyncObject corresponding to an agent's PipelineOp.
        """
        full_name = f"{name}.{phase}" if name and phase else name
        if agent[0] in [
            PipelineOp.AsyncThread,
            PipelineOp.TmaLoad,
            PipelineOp.Composite,
            PipelineOp.AsyncLoad,
        ]:
            return MbarrierArray(
                barrier_storage=barrier_storage,
                num_stages=num_stages,
                agent=agent,
                tx_count=tx_count,
                name=full_name,
            )
        elif agent[0] is PipelineOp.TmaStore:
            # Path taken for AsyncTmaStore
            return TmaStoreFence(num_stages=num_stages)
        else:
            assert False, "Error: Invalid PipelineOp specified."

    @staticmethod
    def create(
        *,
        num_stages: int,
        producer_group: CooperativeGroup,
        consumer_group: CooperativeGroup,
        barrier_storage: Optional[cute.Pointer] = None,
        producer_mask: Optional[Int32] = None,
        consumer_mask: Optional[Int32] = None,
        defer_sync: bool = False,
        name: str = "",
    ) -> "PipelineAsync":
        """Creates and initializes a new PipelineAsync instance.

        This helper function computes necessary attributes and returns an instance of PipelineAsync
        with the specified configuration for producer and consumer synchronization.

        :param barrier_storage: Pointer to the shared memory address for this pipeline's mbarriers
        :type barrier_storage: cute.Pointer
        :param num_stages: Number of buffer stages for this pipeline
        :type num_stages: int
        :param producer_group: ``CooperativeGroup`` for the producer agent
        :type producer_group: CooperativeGroup
        :param consumer_group: ``CooperativeGroup`` for the consumer agent
        :type consumer_group: CooperativeGroup
        :param producer_mask: Mask for signaling arrives for the producer agent
        :type producer_mask: Int32, optional
        :param consumer_mask: Mask for signaling arrives for the consumer agent
        :type consumer_mask: Int32, optional
        :raises ValueError: If barrier_storage is not a cute.Pointer instance
        :return: A new ``PipelineAsync`` instance
        :rtype: PipelineAsync
        """
        # Create barrier storage at reserved low address of smem
        if barrier_storage is None:
            barrier_storage = alloc_reserved_mbarrier(num_stages)
        if not isinstance(barrier_storage, cute.Pointer):
            raise TypeError(
                f"Expected barrier_storage to be a cute.Pointer, but got {type(barrier_storage)}"
            )

        producer_type = PipelineOp.AsyncThread
        consumer_type = PipelineOp.AsyncThread

        producer = (producer_type, producer_group)
        consumer = (consumer_type, consumer_group)

        sync_object_full = PipelineAsync._make_sync_object(
            barrier_storage.align(min_align=8),
            num_stages,
            producer,
            name=name,
            phase="full",
        )
        sync_object_empty = PipelineAsync._make_sync_object(
            barrier_storage.align(min_align=8) + num_stages,
            num_stages,
            consumer,
            name=name,
            phase="empty",
        )

        if name:
            register_barrier(name, num_stages, "PipelineAsync")

        if not defer_sync:
            cute.arch.mbarrier_init_fence()
            agent_sync(Agent.ThreadBlock)

        return PipelineAsync(
            sync_object_full,
            sync_object_empty,
            num_stages,
            producer_mask,
            consumer_mask,
        )

    @dsl_user_op
    def producer_acquire(
        self,
        state: PipelineState,
        try_acquire_token: Optional[Boolean] = None,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        if_generate(
            try_acquire_token is None or try_acquire_token == 0,
            lambda: self.sync_object_empty.wait(
                state.index, state.phase, loc=loc, ip=ip
            ),
            loc=loc,
            ip=ip,
        )

    @dsl_user_op
    def producer_try_acquire(
        self,
        state: PipelineState,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> Boolean:
        return self.sync_object_empty.try_wait(state.index, state.phase, loc=loc, ip=ip)  # type: ignore[attr-defined]

    @dsl_user_op
    def producer_commit(
        self,
        state: PipelineState,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        self.sync_object_full.arrive(state.index, self.producer_mask, loc=loc, ip=ip)

    @dsl_user_op
    def consumer_wait(
        self,
        state: PipelineState,
        try_wait_token: Optional[Boolean] = None,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        if_generate(
            try_wait_token is None or try_wait_token == 0,
            lambda: self.sync_object_full.wait(
                state.index, state.phase, loc=loc, ip=ip
            ),
            loc=loc,
            ip=ip,
        )

    @dsl_user_op
    def consumer_try_wait(
        self,
        state: PipelineState,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> Boolean:
        return self.sync_object_full.try_wait(state.index, state.phase, loc=loc, ip=ip)  # type: ignore[attr-defined]

    @dsl_user_op
    def consumer_release(
        self,
        state: PipelineState,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        self.sync_object_empty.arrive(state.index, self.consumer_mask, loc=loc, ip=ip)

    @dsl_user_op
    def consumer_get_barrier(
        self,
        state: PipelineState,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> cute.Pointer:
        return self.sync_object_empty.get_barrier(state.index, loc=loc, ip=ip)  # type: ignore[call-arg, return-value]

    @dsl_user_op
    def producer_get_barrier(
        self,
        state: PipelineState,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> cute.Pointer:
        return self.sync_object_full.get_barrier(state.index, loc=loc, ip=ip)  # type: ignore[call-arg, return-value]

    @dsl_user_op
    def producer_tail(
        self,
        state: PipelineState,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        """
        Make sure the last used buffer empty signal is visible to producer.
        Producer tail is usually executed by producer before exit, to avoid dangling
        mbarrier arrive signals after kernel exit.

        :param state: The pipeline state that points to next useful buffer
        :type state: PipelineState
        """
        # wait on all stage buffers since there is no guaranteed ordering of empty barrier arrives
        for i in range(self.num_stages):
            self.sync_object_empty.wait(state.index, state.phase, loc=loc, ip=ip)
            state.advance(loc=loc, ip=ip)

    # Util methods to manage producer and consumer
    @dsl_user_op
    def make_producer(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> "PipelineProducer":
        state = make_pipeline_state(
            PipelineUserType.Producer, self.num_stages, loc=loc, ip=ip
        )
        return PipelineProducer(self, state, self.sync_object_full.cg)  # type: ignore[attr-defined]

    @dsl_user_op
    def make_consumer(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> "PipelineConsumer":
        state = make_pipeline_state(
            PipelineUserType.Consumer, self.num_stages, loc=loc, ip=ip
        )
        return PipelineConsumer(self, state, self.sync_object_empty.cg)  # type: ignore[attr-defined]

    @dsl_user_op
    def make_participants(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> "tuple[PipelineProducer, PipelineConsumer]":
        return self.make_producer(loc=loc, ip=ip), self.make_consumer(loc=loc, ip=ip)


@dataclass(frozen=True)
class PipelineCpAsync(PipelineAsync):
    """
    PipelineCpAsync is used for CpAsync producers and AsyncThread consumers (e.g. Hopper load mainloops).
    """

    @staticmethod
    def create(  # type: ignore[override]
        *,
        barrier_storage: cute.Pointer,
        num_stages: Int32,
        producer_group: CooperativeGroup,
        consumer_group: CooperativeGroup,
        producer_mask: Optional[Int32] = None,
        consumer_mask: Optional[Int32] = None,
        defer_sync: bool = False,
        name: str = "",
    ) -> "PipelineCpAsync":
        """Helper function that computes necessary attributes and returns a ``PipelineCpAsync`` instance.

        :param barrier_storage: Pointer to the shared memory address for this pipeline's mbarriers
        :type barrier_storage: cute.Pointer
        :param num_stages: Number of buffer stages for this pipeline
        :type num_stages: Int32
        :param producer_group: ``CooperativeGroup`` for the producer agent
        :type producer_group: CooperativeGroup
        :param consumer_group: ``CooperativeGroup`` for the consumer agent
        :type consumer_group: CooperativeGroup
        :param producer_mask: Mask for signaling arrives for the producer agent, defaults to None
        :type producer_mask: Int32, optional
        :param consumer_mask: Mask for signaling arrives for the consumer agent, defaults to None
        :type consumer_mask: Int32, optional
        :return: A new ``PipelineCpAsync`` instance configured with the provided parameters
        :rtype: PipelineCpAsync
        """
        # Create barrier storage at reserved low address of smem
        if barrier_storage is None:
            barrier_storage = alloc_reserved_mbarrier(num_stages)
        producer_type = PipelineOp.AsyncLoad
        consumer_type = PipelineOp.AsyncThread

        producer = (producer_type, producer_group)
        consumer = (consumer_type, consumer_group)

        sync_object_array_full = PipelineCpAsync._make_sync_object(
            barrier_storage.align(min_align=8),
            num_stages,  # type: ignore[arg-type]
            producer,
            name=name,
            phase="full",
        )
        sync_object_array_empty = PipelineCpAsync._make_sync_object(
            barrier_storage.align(min_align=8) + num_stages,
            num_stages,  # type: ignore[arg-type]
            consumer,
            name=name,
            phase="empty",
        )

        if name:
            register_barrier(name, int(num_stages), "PipelineCpAsync")

        if not defer_sync:
            cute.arch.mbarrier_init_fence()
            agent_sync(Agent.ThreadBlock)

        return PipelineCpAsync(
            sync_object_array_full,
            sync_object_array_empty,
            num_stages,  # type: ignore[arg-type]
            producer_mask,
            consumer_mask,
        )


@dataclass(frozen=True)
class PipelineTmaAsync(PipelineAsync):
    """
    PipelineTmaAsync is used for TMA producers and AsyncThread consumers (e.g. Hopper mainloops).
    """

    is_signaling_thread: Boolean

    @staticmethod
    @cute.jit
    def init_empty_barrier_arrive_signal(
        cta_layout_vmnk: cute.Layout,
        tidx: Int32,
        mcast_mode_mn: tuple[int, int] = (1, 1),
    ) -> tuple[Int32, Boolean]:
        """Initialize the empty barrier arrive signal.

        This function determines which threads should signal empty barrier arrives based on the cluster layout
        and multicast modes. It returns the destination CTA rank and whether the current thread should signal.

        :param cta_layout_vmnk: Layout describing the cluster shape and CTA arrangement
        :type cta_layout_vmnk: cute.Layout
        :param tidx: Thread index within the warp
        :type tidx: Int32
        :param mcast_mode_mn: Tuple specifying multicast modes for m and n dimensions (each 0 or 1), defaults to (1,1)
        :type mcast_mode_mn: tuple[int, int]
        :raises ``AssertionError``: If both multicast modes are disabled (0,0)
        :return: Tuple containing destination CTA rank and boolean indicating if current thread signals
        :rtype: tuple[Int32, Boolean]
        """
        # Logic to optimally schedule Empty Arrives
        cluster_shape_vmnk = cta_layout_vmnk.shape

        cta_rank_in_cluster = cute.arch.make_warp_uniform(
            cute.arch.block_idx_in_cluster()
        )

        tidx = tidx % WARP_SIZE
        is_signaling_thread = tidx < cute.size(cluster_shape_vmnk)
        dst_rank = tidx % cute.size(cluster_shape_vmnk)

        dst_cta_coord = cta_layout_vmnk.get_hier_coord(dst_rank)
        cur_cta_coord = cta_layout_vmnk.get_hier_coord(cta_rank_in_cluster)
        assert isinstance(dst_cta_coord, tuple)
        assert isinstance(cur_cta_coord, tuple)

        is_mcast_mode_m = (
            dst_cta_coord[0] == cur_cta_coord[0]
            and dst_cta_coord[1] == cur_cta_coord[1]
            and dst_cta_coord[3] == cur_cta_coord[3]
        )
        is_mcast_mode_n = (
            dst_cta_coord[0] == cur_cta_coord[0]
            and dst_cta_coord[2] == cur_cta_coord[2]
            and dst_cta_coord[3] == cur_cta_coord[3]
        )

        assert not (mcast_mode_mn[0] == 0 and mcast_mode_mn[1] == 0)
        if mcast_mode_mn[0] == 1 and mcast_mode_mn[1] == 0:
            is_signaling_thread = is_signaling_thread and is_mcast_mode_m
        elif mcast_mode_mn[0] == 0 and mcast_mode_mn[1] == 1:
            is_signaling_thread = is_signaling_thread and is_mcast_mode_n
        elif mcast_mode_mn[0] == 1 and mcast_mode_mn[1] == 1:
            is_mcast_mode_m_or_n = is_mcast_mode_m or is_mcast_mode_n
            is_signaling_thread = is_signaling_thread and is_mcast_mode_m_or_n

        return dst_rank, is_signaling_thread

    @staticmethod
    def create(  # type: ignore[override]
        *,
        num_stages: int,
        producer_group: CooperativeGroup,
        consumer_group: CooperativeGroup,
        tx_count: int,
        barrier_storage: Optional[cute.Pointer] = None,
        cta_layout_vmnk: Optional[cute.Layout] = None,
        tidx: Optional[Int32] = None,
        mcast_mode_mn: tuple[int, int] = (1, 1),
        enable_multicast_signaling: bool = False,
        defer_sync: bool = False,
        name: str = "",
    ) -> "PipelineTmaAsync":
        """Create a new ``PipelineTmaAsync`` instance.

        :param num_stages: Number of buffer stages for this pipeline
        :type num_stages: int
        :param producer_group: ``CooperativeGroup`` for the producer agent
        :type producer_group: CooperativeGroup
        :param consumer_group: ``CooperativeGroup`` for the consumer agent
        :type consumer_group: CooperativeGroup
        :param tx_count: Number of bytes expected to be written to the transaction barrier for one stage
        :type tx_count: int
        :param barrier_storage: Pointer to the shared memory address for this pipeline's mbarriers, defaults to None
        :type barrier_storage: cute.Pointer, optional
        :param cta_layout_vmnk: Layout of the cluster shape, defaults to None
        :type cta_layout_vmnk: cute.Layout, optional
        :param tidx: Thread index to consumer async threads, defaults to None
        :type tidx: Int32, optional
        :param mcast_mode_mn: Tuple specifying multicast modes for m and n dimensions (each 0 or 1), defaults to (1,1)
        :type mcast_mode_mn: tuple[int, int], optional
        :param enable_multicast_signaling: When ``True``, the CooperativeGroup is expected
            to represent the number of threads in a CTA calling
            consumer_wait/consumer_release, and the actual arrive count is recomputed
            internally. Multicast is handled automatically based on cta_layout_vmnk and
            mcast_mode_mn. Defaults to ``False``, which skips this logic and uses the
            consumer arrive count specified by the user.
        :type enable_multicast_signaling: bool, optional
        :param defer_sync: Bool specifying whether or not to skip the built-in mbarrier fence and sync for performance, defaults to False
        :type defer_sync: bool, optional
        :raises ValueError: If barrier_storage is not a cute.Pointer instance
        :return: New ``PipelineTmaAsync`` instance
        :rtype: PipelineTmaAsync
        """
        # Create barrier storage at reserved low address of smem
        if barrier_storage is None:
            barrier_storage = alloc_reserved_mbarrier(num_stages)
        if not isinstance(barrier_storage, cute.Pointer):
            raise TypeError(
                f"Expected barrier_storage to be a cute.Pointer, but got {type(barrier_storage)}"
            )

        if not is_static(cta_layout_vmnk):
            raise ValueError("The cluster shape (cta_layout_vmnk) needs to be static.")

        if cta_layout_vmnk is None:
            cta_layout_vmnk = cute.make_layout((1, 1, 1, 1))

        producer_type = PipelineOp.TmaLoad
        consumer_type = PipelineOp.AsyncThread

        # The producer group is not dependent on multicast and is forwarded as-is.
        thread_producer_group = producer_group

        if enable_multicast_signaling:
            # In multicast mode, the consumer arrive count is recomputed. Each
            # consumer warp contributes one signaling thread per multicast partner
            # CTA to the arrive count, rather than using the thread count directly.
            consumer_thread_arrive_cnt = _get_thread_arrive_count(consumer_group)

            if (
                isinstance(consumer_thread_arrive_cnt, int)
                and consumer_thread_arrive_cnt % WARP_SIZE != 0
            ):
                raise ValueError(
                    "Error: Consumer arrival count must be aligned with warp size"
                )

            shape_vmnk = cast(tuple[int, ...], cta_layout_vmnk.shape)
            # mcast_m_size is the number of multicast partners in the m dimension
            mcast_m_size = shape_vmnk[2] if mcast_mode_mn[0] else 0
            # mcast_n_size is the number of multicast partners in the n dimension
            mcast_n_size = shape_vmnk[1] if mcast_mode_mn[1] else 0
            # Subtracting by 1 is necessary if multicasting in both the m and n
            # dimensions to avoid double counting the local CTA
            overlap = 1 if (mcast_mode_mn[0] and mcast_mode_mn[1]) else 0
            # mcast_size is the total number of multicast partners
            mcast_size = mcast_m_size + mcast_n_size - overlap
            assert mcast_size > 0, "Mcast size must be greater than 0."

            num_warps = consumer_thread_arrive_cnt // WARP_SIZE
            # num_signaling_threads is the total number of arrives expected. One
            # arrive is expected per consumer warp, per multicast partner.
            num_signaling_threads = mcast_size * num_warps

            thread_consumer_group = CooperativeGroup(
                Agent.Thread, num_signaling_threads
            )

        else:
            # Non-multicast signaling path
            thread_consumer_group = consumer_group

        producer = (producer_type, thread_producer_group)
        consumer = (consumer_type, thread_consumer_group)

        sync_object_full = PipelineAsync._make_sync_object(
            barrier_storage.align(min_align=8),
            num_stages,
            producer,
            tx_count,
            name=name,
            phase="full",
        )
        sync_object_empty = PipelineAsync._make_sync_object(
            barrier_storage.align(min_align=8) + num_stages,
            num_stages,
            consumer,
            name=name,
            phase="empty",
        )

        if name:
            register_barrier(name, num_stages, "PipelineTmaAsync")

        if tidx is None:
            tidx, _, _ = cute.arch.thread_idx()
        (
            dst_rank,
            is_signaling_thread,
        ) = PipelineTmaAsync.init_empty_barrier_arrive_signal(
            cta_layout_vmnk, tidx, mcast_mode_mn
        )
        if cute.size(cta_layout_vmnk) == 1:
            dst_rank = None
        else:
            dst_rank = dst_rank

        producer_mask = None

        if not defer_sync:
            cute.arch.mbarrier_init_fence()
            if cute.size(cta_layout_vmnk) == 1:
                agent_sync(Agent.ThreadBlock)
            else:
                agent_sync(Agent.ThreadBlockCluster, is_relaxed=True)

        return PipelineTmaAsync(
            sync_object_full,
            sync_object_empty,
            num_stages,
            producer_mask,  # unused
            dst_rank,
            is_signaling_thread,
        )

    @dsl_user_op
    def producer_acquire(
        self,
        state: PipelineState,
        try_acquire_token: Optional[Boolean] = None,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        """
        TMA producer commit conditionally waits on buffer empty and sets the transaction barrier.
        """
        if_generate(
            try_acquire_token is None or try_acquire_token == 0,
            lambda: self.sync_object_empty.wait(
                state.index, state.phase, loc=loc, ip=ip
            ),
            loc=loc,
            ip=ip,
        )
        self.sync_object_full.arrive(state.index, self.producer_mask, loc=loc, ip=ip)

    @dsl_user_op
    def producer_commit(
        self,
        state: PipelineState,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        """
        TMA producer commit is a noop since TMA instruction itself updates the transaction count.
        """
        pass

    @dsl_user_op
    def consumer_release(
        self,
        state: PipelineState,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        """
        TMA consumer release conditionally signals the empty buffer to the producer.
        """
        if_generate(
            self.is_signaling_thread,
            lambda: self.sync_object_empty.arrive(
                state.index, self.consumer_mask, loc=loc, ip=ip
            ),
        )


@dataclass(frozen=True)
class PipelineTmaStore(PipelineAsync):
    """
    PipelineTmaStore is used for synchronizing TMA stores in the epilogue. It does not use mbarriers.
    """

    @staticmethod
    def create(  # type: ignore[override]
        *,
        num_stages: int,
        producer_group: CooperativeGroup,
    ) -> "PipelineTmaStore":
        """This helper function computes any necessary attributes and returns an instance of ``PipelineTmaStore``.

        :param num_stages: Number of buffer stages for this pipeline
        :type num_stages: int
        :param producer_group: ``CooperativeGroup`` for the producer agent
        :type producer_group: CooperativeGroup
        :return: A new ``PipelineTmaStore`` instance
        :rtype: PipelineTmaStore
        """
        producer_type = PipelineOp.TmaStore

        producer = (producer_type, producer_group)

        sync_object_full = PipelineAsync._make_sync_object(None, num_stages, producer)  # type: ignore[arg-type]

        return PipelineTmaStore(sync_object_full, None, num_stages, None, None)  # type: ignore[arg-type]

    @dsl_user_op
    def producer_acquire(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        self.sync_object_full.wait(loc=loc, ip=ip)

    @dsl_user_op
    def producer_commit(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        self.sync_object_full.arrive(loc=loc, ip=ip)

    @dsl_user_op
    def consumer_wait(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        assert False, "Error: PipelineTmaStore does not have a consumer agent."

    @dsl_user_op
    def consumer_release(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        assert False, "Error: PipelineTmaStore does not have a consumer agent."

    @dsl_user_op
    def producer_tail(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        self.sync_object_full.tail(loc=loc, ip=ip)  # type: ignore[attr-defined]


@dataclass(frozen=True)
class PipelineOrder:
    """
    PipelineOrder is used for managing ordered pipeline execution with multiple groups.

    This class implements a pipeline ordering mechanism where work is divided into groups
    and stages, allowing for controlled progression through pipeline stages with proper
    synchronization between different groups.

    The pipeline ordering works as follows:
    - The pipeline is divided into 'length' number of groups
    - Each group has 'depth' number of stages
    - Groups execute in a specific order with synchronization barriers
    - Each group waits for the previous group to complete before proceeding

    **Example:**

    .. code-block:: python

        # Create pipeline order with 3 groups, each with 2 stages
        pipeline_order = PipelineOrder.create(
            barrier_storage=smem_ptr,      # shared memory pointer for barriers
            depth=2,                       # 2 stages per group
            length=3,                      # 3 groups total
            group_id=0,                    # current group ID (0, 1, or 2)
            producer_group=producer_warp   # cooperative group for producers
        )

        # In the pipeline loop
        for stage in range(num_stages):
            pipeline_order.wait()          # Wait for previous group to complete
            # Process current stage
            pipeline_order.arrive()        # Signal completion to next group
    """

    sync_object_full: SyncObject
    depth: int
    length: int
    group_id: int
    state: PipelineState

    @staticmethod
    def create(
        *,
        depth: int,
        length: int,
        group_id: int,
        producer_group: CooperativeGroup,
        barrier_storage: Optional[cute.Pointer] = None,
        defer_sync: bool = False,
        name: str = "",
    ) -> "PipelineOrder":
        # Create barrier storage at reserved low address of smem
        if barrier_storage is None:
            barrier_storage = alloc_reserved_mbarrier(depth * length)
        if not isinstance(barrier_storage, cute.Pointer):
            raise TypeError(
                f"Expected barrier_storage to be a cute.Pointer, but got {type(barrier_storage)}"
            )

        producer_type = PipelineOp.AsyncThread

        producer = (producer_type, producer_group)

        num_stages = depth * length

        sync_object_full = PipelineAsync._make_sync_object(
            barrier_storage.align(min_align=8),
            num_stages,
            producer,
            name=name,
        )

        if name:
            register_barrier(name, num_stages, "PipelineOrder")

        if not defer_sync:
            cute.arch.mbarrier_init_fence()
            agent_sync(Agent.ThreadBlock)

        return PipelineOrder(
            sync_object_full,
            depth,
            length,
            group_id,
            PipelineState(
                depth,
                Int32(0),
                Int32(0),
                Int32(group_id == 0),  # phase
            ),
        )

    def get_barrier_for_current_stage_idx(
        self, group_id: int, state: Optional[PipelineState] = None
    ) -> Int32:
        state = self.state if state is None else state
        return state.index * self.length + group_id

    @dsl_user_op
    def arrive(
        self,
        state: Optional[PipelineState] = None,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> Optional[PipelineState]:
        state = self.state if state is None else state
        signaling_id = (self.group_id + 1) % self.length
        idx = self.get_barrier_for_current_stage_idx(signaling_id, state)
        cute.arch.mbarrier_arrive(
            self.sync_object_full.get_barrier(idx, loc=loc, ip=ip),  # type: ignore[call-arg]
            loc=loc,
            ip=ip,
        )
        state.advance(loc=loc, ip=ip)
        if state is not self.state:
            return state
        return None

    @dsl_user_op
    def wait(
        self,
        state: Optional[PipelineState] = None,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        state = self.state if state is None else state
        idx = self.get_barrier_for_current_stage_idx(self.group_id, state)
        cute.arch.mbarrier_wait(
            self.sync_object_full.get_barrier(idx, loc=loc, ip=ip),  # type: ignore[call-arg]
            state.phase,
            loc=loc,
            ip=ip,
        )


#################################################################
# Utilities to help user of pipeline to simplify the workflow
#################################################################


@dataclass(frozen=True)
class ImmutableResourceHandle:
    __origin: PipelineAsync
    __immutable_state: PipelineState

    def __init__(self, origin: PipelineAsync, immutable_state: PipelineState):
        self.__origin = origin  # type: ignore[misc]
        self.__immutable_state = immutable_state  # type: ignore[misc]

    @property
    def index(self) -> Int32:
        """Get the index of the current pipeline stage."""
        return self.__immutable_state.index

    @property
    def count(self) -> Int32:
        """Get the count of how many handles this producer has committed.
        This is useful for tracking the number of blocks that have been loaded from gmem.
        """
        return self.__immutable_state.count

    def get_origin(self) -> PipelineAsync:
        """Get the original pipeline this resource handle belongs to."""
        return self.__origin

    def __extract_mlir_values__(self) -> list[ir.Value]:
        """Extract MLIR values from the current state.

        :return: List of MLIR values representing the current state
        :rtype: list
        """
        # TODO: need to handle pipeline as well
        return self.__immutable_state.__extract_mlir_values__()

    def __new_from_mlir_values__(
        self, values: list[ir.Value]
    ) -> "ImmutableResourceHandle":
        """Create a new Producer instance from MLIR values.

        :param values: MLIR values to initialize the state
        :type values: Any
        :return: New Producer instance with state initialized from values
        :rtype: Producer
        """
        return self.__class__(
            self.__origin, self.__immutable_state.__new_from_mlir_values__(values)
        )


class PipelineProducer:
    """A class representing a producer in an asynchronous pipeline.

    This class manages the producer side of an asynchronous pipeline, handling
    synchronization and state management for producing data. It provides methods for
    acquiring, committing, and advancing through pipeline stages.

    :ivar __pipeline: The asynchronous pipeline this producer belongs to
    :type __pipeline: PipelineAsync
    :ivar __state: The current state of the producer in the pipeline
    :type __state: PipelineState
    :ivar __group: The cooperative group this producer operates in
    :type __group: CooperativeGroup

    **Examples:**

    .. code-block:: python

        pipeline = PipelineAsync.create(...)
        producer, consumer = pipeline.make_participants()
        for i in range(iterations):
            # Try to acquire the current buffer without blocking
            try_acquire_token = producer.try_acquire()

            # Do something else independently
            ...

            # Wait for current buffer to be empty & Move index to next stage
            # If try_acquire_token is True, return immediately
            # If try_acquire_token is False, block until buffer is empty
            handle = producer.acquire_and_advance(try_acquire_token)

            # Produce data
            handle.commit()
    """

    __pipeline: PipelineAsync
    __state: PipelineState
    __group: CooperativeGroup

    @dataclass(frozen=True)
    class ImmutableResourceHandle(ImmutableResourceHandle):
        @property
        def barrier(self) -> cute.Pointer:
            """Get the barrier pointer for the current pipeline stage.

            :return: Pointer to the barrier for the current stage
            :rtype: cute.Pointer
            """
            return self.get_origin().producer_get_barrier(
                self._ImmutableResourceHandle__immutable_state  # type: ignore[attr-defined]
            )

        @dsl_user_op
        def commit(
            self,
            *,
            loc: Optional[ir.Location] = None,
            ip: Optional[ir.InsertionPoint] = None,
        ) -> None:
            """Signal that data production is complete for the current stage.

            This allows consumers to start processing the data.
            """
            self.get_origin().producer_commit(
                self._ImmutableResourceHandle__immutable_state,  # type: ignore[attr-defined]
                loc=loc,
                ip=ip,
            )

    def __init__(
        self, pipeline: PipelineAsync, state: PipelineState, group: CooperativeGroup
    ) -> None:
        """Initialize a new Producer instance.

        :param pipeline: The pipeline this producer belongs to
        :type pipeline: PipelineAsync
        :param state: Initial pipeline state
        :type state: PipelineState
        :param group: The cooperative group for synchronization
        :type group: CooperativeGroup
        """
        self.__pipeline = pipeline
        self.__state = state
        self.__group = group

    def clone(self) -> "PipelineProducer":
        """Create a new Producer instance with the same state."""
        return PipelineProducer(self.__pipeline, self.__state.clone(), self.__group)

    @dsl_user_op
    def reset(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        """Reset the count of how many handles this producer has committed."""
        self.__state.reset_count(loc=loc, ip=ip)

    def current_handle(self) -> ImmutableResourceHandle:
        """Get the current handle for the producer."""
        return PipelineProducer.ImmutableResourceHandle(self.__pipeline, self.__state)

    @dsl_user_op
    def acquire(
        self,
        try_acquire_token: Optional[Boolean] = None,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
        **kwargs: Any,
    ) -> ImmutableResourceHandle:
        """Wait for the current buffer to be empty before producing data.
        This is a blocking operation.

        :param try_acquire_token: Optional token to try to acquire the buffer
        :type try_acquire_token: Optional[Boolean]
        :return: A handle to the producer for committing the data
        :rtype: ImmutableResourceHandle
        """
        self.__pipeline.producer_acquire(
            self.__state, try_acquire_token, loc=loc, ip=ip, **kwargs
        )
        handle = PipelineProducer.ImmutableResourceHandle(
            self.__pipeline, self.__state.clone()
        )
        return handle

    @dsl_user_op
    def advance(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        """Move to the next pipeline stage."""
        self.__state.advance(loc=loc, ip=ip)

    @dsl_user_op
    def acquire_and_advance(
        self,
        try_acquire_token: Optional[Boolean] = None,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
        **kwargs: Any,
    ) -> ImmutableResourceHandle:
        """Acquire the current buffer and advance to the next pipeline stage.

        This method combines the acquire() and advance() operations into a single call.
        It first waits for the current buffer to be empty before producing data,
        then advances the pipeline to the next stage.

        :param try_acquire_token: Token indicating whether to try non-blocking acquire.
            If True, returns immediately without waiting. If False or None, blocks
            until buffer is empty.
        :type try_acquire_token: Optional[Boolean]
        :return: A handle to the producer that can be used to commit data to the
            acquired buffer stage
        :rtype: ImmutableResourceHandle
        """
        handle = self.acquire(try_acquire_token, loc=loc, ip=ip, **kwargs)
        self.advance(loc=loc, ip=ip)
        return handle

    @dsl_user_op
    def try_acquire(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> Boolean:
        """Attempt to acquire the current buffer without blocking.

        This method tries to acquire the current buffer stage for producing data
        without waiting. It can be used to check buffer availability before
        committing to a blocking acquire operation.

        :return: A boolean token indicating whether the buffer was successfully acquired
        :rtype: Boolean
        """
        return self.__pipeline.producer_try_acquire(self.__state, loc=loc, ip=ip)

    @dsl_user_op
    def commit(
        self,
        handle: Optional[ImmutableResourceHandle] = None,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        """Signal that data production is complete for the current stage.

        This allows consumers to start processing the data.

        :param handle: Optional handle to commit, defaults to None
        :type handle: Optional[ImmutableResourceHandle]
        :raises AssertionError: If provided handle does not belong to this producer
        """
        if handle is not None:
            assert handle.get_origin() is self.__pipeline, (
                "ResourceHandle does not belong to this PipelineProducer instance"
            )
            handle.commit(loc=loc, ip=ip)
        else:
            self.__pipeline.producer_commit(self.__state, loc=loc, ip=ip)

    @dsl_user_op
    def tail(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        """Ensure all used buffers are properly synchronized before producer exit.

        This should be called before the producer finishes to avoid dangling signals.
        """
        self.__pipeline.producer_tail(self.__state, loc=loc, ip=ip)

    def __extract_mlir_values__(self) -> list[ir.Value]:
        """Extract MLIR values from the current state.

        :return: List of MLIR values representing the current state
        :rtype: list
        """
        # TODO: need to handle pipeline as well
        return self.__state.__extract_mlir_values__()

    def __new_from_mlir_values__(self, values: list[ir.Value]) -> "PipelineProducer":
        """Create a new Producer instance from MLIR values.

        :param values: MLIR values to initialize the state
        :type values: Any
        :return: New Producer instance with state initialized from values
        :rtype: Producer
        """
        return PipelineProducer(
            self.__pipeline, self.__state.__new_from_mlir_values__(values), self.__group
        )


class PipelineConsumer:
    """A class representing a consumer in an asynchronous pipeline.

    The Consumer class manages the consumer side of an asynchronous pipeline, handling
    synchronization and state management for consuming data. It provides methods for
    waiting, releasing, and advancing through pipeline stages.

    :ivar __pipeline: The asynchronous pipeline this consumer belongs to
    :type __pipeline: PipelineAsync
    :ivar __state: The current state of the consumer in the pipeline
    :type __state: PipelineState
    :ivar __group: The cooperative group this consumer operates in
    :type __group: CooperativeGroup

    **Examples:**

    .. code-block:: python

        pipeline = PipelineAsync.create(...)
        producer, consumer = pipeline.make_participants()
        for i in range(iterations):
            # Try to wait for buffer to be full
            try_wait_token = consumer.try_wait()

            # Do something else independently
            ...

            # Wait for buffer to be full & Move index to next stage
            # If try_wait_token is True, return immediately
            # If try_wait_token is False, block until buffer is full
            handle = consumer.wait_and_advance(try_wait_token)

            # Consume data
            handle.release(  )  # Signal buffer is empty

            # Alternative way to do this is:
            # handle.release()  # Signal buffer is empty
    """

    __pipeline: PipelineAsync
    __state: PipelineState
    __group: CooperativeGroup

    @dataclass(frozen=True)
    class ImmutableResourceHandle(ImmutableResourceHandle):
        @property
        def barrier(self) -> cute.Pointer:
            """Get the barrier pointer for the current pipeline stage.

            :return: Pointer to the barrier for the current stage
            :rtype: cute.Pointer
            """
            return self.get_origin().consumer_get_barrier(
                self._ImmutableResourceHandle__immutable_state  # type: ignore[attr-defined]
            )

        @dsl_user_op
        def release(
            self,
            *,
            loc: Optional[ir.Location] = None,
            ip: Optional[ir.InsertionPoint] = None,
        ) -> None:
            """Signal that data production is complete for the current stage.
            This allows consumers to start processing the data.
            """
            self.get_origin().consumer_release(
                self._ImmutableResourceHandle__immutable_state,  # type: ignore[attr-defined]
                loc=loc,
                ip=ip,
            )

    def __init__(
        self, pipeline: PipelineAsync, state: PipelineState, group: CooperativeGroup
    ) -> None:
        """Initialize a new Consumer instance.

        :param pipeline: The pipeline this consumer belongs to
        :type pipeline: PipelineAsync
        :param state: Initial pipeline state
        :type state: PipelineState
        :param group: The cooperative group for synchronization
        :type group: CooperativeGroup
        """
        self.__pipeline = pipeline
        self.__group = group
        self.__state = state

    def clone(self) -> "PipelineConsumer":
        """Create a new Consumer instance with the same state."""
        return PipelineConsumer(self.__pipeline, self.__state.clone(), self.__group)

    @dsl_user_op
    def reset(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        """Reset the count of how many handles this consumer has consumed."""
        self.__state.reset_count(loc=loc, ip=ip)

    def current_handle(self) -> ImmutableResourceHandle:
        """Get the current handle for the consumer."""
        return PipelineConsumer.ImmutableResourceHandle(self.__pipeline, self.__state)

    @dsl_user_op
    def wait(
        self,
        try_wait_token: Optional[Boolean] = None,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> ImmutableResourceHandle:
        """Wait for data to be ready in the current buffer. This is a blocking operation
        that will not return until data is available.

        :param try_wait_token: Token used to attempt a non-blocking wait for the buffer.
            If provided and True, returns immediately if buffer is not ready.
        :type try_wait_token: Optional[Boolean]
        :return: An immutable handle to the consumer that can be used to release the buffer
            once data consumption is complete
        :rtype: ImmutableResourceHandle
        """
        self.__pipeline.consumer_wait(self.__state, try_wait_token, loc=loc, ip=ip)
        handle = PipelineConsumer.ImmutableResourceHandle(
            self.__pipeline, self.__state.clone()
        )
        return handle

    @dsl_user_op
    def advance(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        """Advance the consumer to the next pipeline stage.

        This updates the internal state to point to the next buffer in the pipeline.
        Should be called after consuming data from the current buffer.
        """
        self.__state.advance(loc=loc, ip=ip)

    @dsl_user_op
    def wait_and_advance(
        self,
        try_wait_token: Optional[Boolean] = None,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> ImmutableResourceHandle:
        """Atomically wait for data and advance to next pipeline stage.

        This is a convenience method that combines wait() and advance() into a single
        atomic operation. It will block until data is available in the current buffer,
        then automatically advance to the next stage.

        :param try_wait_token: Token used to attempt a non-blocking wait for the buffer.
            If provided and True, returns immediately if buffer is not ready.
        :type try_wait_token: Optional[Boolean]
        :return: An immutable handle to the consumer that can be used to release the buffer
            once data consumption is complete
        :rtype: ImmutableResourceHandle
        """
        handle = self.wait(try_wait_token, loc=loc, ip=ip)
        self.advance(loc=loc, ip=ip)
        return handle

    @dsl_user_op
    def try_wait(
        self,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> Boolean:
        """Non-blocking check if data is ready in the current buffer.

        This method provides a way to test if data is available without blocking.
        Unlike wait(), this will return immediately regardless of buffer state.

        :return: True if data is ready to be consumed, False if the buffer is not yet ready
        :rtype: Boolean
        """
        return self.__pipeline.consumer_try_wait(self.__state, loc=loc, ip=ip)

    @dsl_user_op
    def release(
        self,
        handle: Optional[ImmutableResourceHandle] = None,
        *,
        loc: Optional[ir.Location] = None,
        ip: Optional[ir.InsertionPoint] = None,
    ) -> None:
        """Signal that data consumption is complete for the current stage.
        This allows producers to start producing new data.
        """
        if handle is not None:
            assert handle.get_origin() is self.__pipeline, (
                "ResourceHandle does not belong to this PipelineConsumer instance"
            )
            handle.release(loc=loc, ip=ip)
        else:
            self.__pipeline.consumer_release(self.__state, loc=loc, ip=ip)

    def __extract_mlir_values__(self) -> list[ir.Value]:
        """Extract MLIR values from the current state.

        :return: List of MLIR values representing the current state
        :rtype: list
        """
        return self.__state.__extract_mlir_values__()

    def __new_from_mlir_values__(self, values: list[ir.Value]) -> "PipelineConsumer":
        """Create a new Consumer instance from MLIR values.

        :param values: MLIR values to initialize the state
        :type values: Any
        :return: New Consumer instance with state initialized from values
        :rtype: Consumer
        """
        # TODO: need to call pipeline.__new_from_mlir_values__ recursively
        return PipelineConsumer(
            self.__pipeline, self.__state.__new_from_mlir_values__(values), self.__group
        )
