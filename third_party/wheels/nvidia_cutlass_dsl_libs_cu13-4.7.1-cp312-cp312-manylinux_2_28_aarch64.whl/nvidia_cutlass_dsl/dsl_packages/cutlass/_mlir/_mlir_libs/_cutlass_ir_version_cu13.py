"""Build-generated compile-cache fingerprint of the compiler DSO."""

DSO_SHA256 = {
    "_cutlass_ir.cu13.cpython-312-aarch64-linux-gnu.so": "df74991192905ac3488ad47b8728cdfd25f6f13c982a061dd5512932674c6ff5",
}
