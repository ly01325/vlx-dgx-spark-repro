import contextlib
import functools
import inspect
import os
import subprocess
import sys
import types
import typing
from pathlib import Path
from typing import Callable

import torch
import torch.utils.cpp_extension
from filelock import FileLock
from torch._subclasses.fake_tensor import FakeTensor

import humming.utils.jit as jit_utils
from humming.utils.cuda import filter_cuda_paths

_libs = {}
_launcher_inited = False


def _is_optional_tensor(annotation) -> bool:
    args = typing.get_args(annotation)
    return len(args) == 2 and torch.Tensor in args and type(None) in args


def _infer_op_schema(impl_func: Callable, mutates_args: list[str]) -> str:
    """Infer an op schema, adding Optional[Tensor] output support missing in PyTorch."""
    signature = inspect.signature(impl_func)
    return_annotation = typing.get_type_hints(impl_func).get(
        "return",
        signature.return_annotation,
    )
    tuple_args = typing.get_args(return_annotation)
    tuple_return = typing.get_origin(return_annotation) is tuple
    optional_outputs = (
        [_is_optional_tensor(arg) for arg in tuple_args]
        if tuple_return
        else [_is_optional_tensor(return_annotation)]
    )
    if not any(optional_outputs):
        return torch.library.infer_schema(impl_func, mutates_args=mutates_args)

    normalized_return = torch.Tensor
    if tuple_return:
        normalized_args = tuple(
            torch.Tensor if optional else arg
            for arg, optional in zip(tuple_args, optional_outputs, strict=True)
        )
        normalized_return = tuple[normalized_args]

    def schema_prototype():
        pass

    prototype = types.FunctionType(
        schema_prototype.__code__,
        impl_func.__globals__,
        impl_func.__name__,
    )
    prototype.__signature__ = signature.replace(return_annotation=normalized_return)
    schema = torch.library.infer_schema(prototype, mutates_args=mutates_args)
    arguments, returns = schema.rsplit(" -> ", 1)

    if not tuple_return:
        assert returns == "Tensor"
        return f"{arguments} -> Tensor?"

    if len(optional_outputs) == 1:
        assert returns.startswith("((") and returns.endswith("))")
        return_types = [returns[2:-2]]
    else:
        assert returns.startswith("(") and returns.endswith(")")
        return_types = returns[1:-1].split(", ")
    for index, optional in enumerate(optional_outputs):
        if optional:
            assert return_types[index] == "Tensor"
            return_types[index] = "Tensor?"
    if len(return_types) == 1:
        return f"{arguments} -> (({return_types[0]}))"
    return f"{arguments} -> ({', '.join(return_types)})"


def _prepare_output(
    outputs: torch.Tensor,
    shape: tuple[int, ...],
    dtype: torch.dtype,
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor]:
    if outputs.nelement() > 0:
        assert outputs.shape == shape
        assert outputs.dtype == dtype
        assert outputs.device == device
        assert outputs.is_contiguous()
        returned_outputs = outputs.new_empty((0,))
    else:
        outputs = torch.empty(shape, dtype=dtype, device=device)
        returned_outputs = outputs
    return outputs, returned_outputs


def _prepare_output_arg(
    inputs: torch.Tensor,
    outputs: torch.Tensor | None,
    dtype: torch.dtype,
) -> torch.Tensor:
    assert outputs is None or outputs.nelement() > 0
    return inputs.new_empty((0,), dtype=dtype) if outputs is None else outputs


def _should_use_torch_op(inputs: torch.Tensor) -> bool:
    return torch.compiler.is_compiling() or isinstance(inputs, FakeTensor)


def _select_output(outputs: torch.Tensor, returned_outputs: torch.Tensor) -> torch.Tensor:
    return outputs if outputs.nelement() > 0 else returned_outputs


def register_op(
    name: str,
    mutates_args: list[str] | None = None,
):
    def decorator(impl_func: Callable):
        schema_str = _infer_op_schema(impl_func, mutates_args or [])
        lib_name, op_name = name.split("::")
        first_arg_name = next(iter(inspect.signature(impl_func).parameters))

        @functools.wraps(impl_func)
        def device_guarded_impl(*args, **kwargs):
            device_guard = args[0] if args else kwargs[first_arg_name]
            if isinstance(device_guard, FakeTensor) or not device_guard.is_cuda:
                return impl_func(*args, **kwargs)
            with torch.cuda.device(device_guard.device):
                return impl_func(*args, **kwargs)

        if lib_name not in _libs:
            _libs[lib_name] = torch.library.Library(lib_name, "FRAGMENT")

        lib = _libs[lib_name]
        lib.define(op_name + schema_str)
        lib.impl(op_name, device_guarded_impl, dispatch_key="CUDA")
        with _shield_lazy_modules():
            lib._register_fake(op_name, impl_func)
        return device_guarded_impl

    return decorator


@contextlib.contextmanager
def _shield_lazy_modules():
    saved = {}
    for name, mod in list(sys.modules.items()):
        if mod is not None and type(mod).__name__ == "_LazyModule":
            saved[name] = sys.modules.pop(name)
    try:
        yield
    finally:
        sys.modules.update(saved)


def get_humming_launcher_build_dir(use_torch_stable_api: bool):
    import humming

    dirname = os.path.dirname(humming.__file__)
    launcher_code_hash = jit_utils.hash_path_content(
        path=os.path.join(dirname, "csrc/launcher/"),
        releative=True,
    )

    cache_dir = jit_utils.get_humming_cache_dir()
    torch_major, torch_minor = torch.__version__.split(".")[:2]
    version = "torch211_stable" if use_torch_stable_api else f"torch{torch_major}{torch_minor}_nostable"
    version += "_" + jit_utils.hash_to_hex(jit_utils.get_native_platform_signature())

    launcher_build_dir = os.path.join(cache_dir, f"launcher/{version}/{launcher_code_hash}")
    Path(launcher_build_dir).mkdir(exist_ok=True, parents=True)
    return launcher_build_dir


def _resolve_use_torch_stable_api() -> bool:
    from packaging.version import Version

    override = os.environ.get("HUMMING_USE_TORCH_STABLE_API")
    if override is not None:
        return override.strip().lower() in ("1", "true", "yes", "on")
    return Version(torch.__version__) >= Version("2.11")


def _get_precompiled_launcher_path() -> Path | None:
    from packaging.version import Version

    if Version(torch.__version__) < Version("2.11"):
        return None

    humming_dir = Path(__file__).parents[1]
    csrc_dir = humming_dir / "csrc" / "launcher"
    return jit_utils.get_precompiled_artifact_path(csrc_dir, "libhumming_launcher.so")


def init_humming_launcher():
    global _launcher_inited
    if _launcher_inited:
        return

    USE_TORCH_STABLE_API = _resolve_use_torch_stable_api()
    lock_filename = jit_utils.get_humming_lock_filename("launcher")
    with FileLock(lock_filename):
        if _launcher_inited:
            return
        precompiled_path = _get_precompiled_launcher_path() if USE_TORCH_STABLE_API else None
        if precompiled_path is not None:
            torch.ops.load_library(str(precompiled_path))
            _launcher_inited = True
            return

        import humming

        build_dir = get_humming_launcher_build_dir(USE_TORCH_STABLE_API)
        torch_lock_file = os.path.join(build_dir, "lock")
        if os.path.exists(torch_lock_file):
            os.unlink(torch_lock_file)

        dirname = os.path.dirname(humming.__file__)
        filename = os.path.join(dirname, "csrc/launcher/launcher.cpp")

        cuda_env = filter_cuda_paths(
            required_headers=["cuda.h", "crt/host_defines.h", "cuda/std/cstdint"],
        )

        extra_cflags = ["-O3", f"-DUSE_TORCH_STABLE_API={int(USE_TORCH_STABLE_API)}"]
        if USE_TORCH_STABLE_API:
            extra_cflags.append("-DTORCH_TARGET_VERSION=0x020B000000000000")

        torch.utils.cpp_extension.load(
            name="humming_launcher",
            sources=[filename],
            extra_include_paths=list(cuda_env["include_paths"]),
            extra_ldflags=["-lcuda", "-lc10_cuda", "-ltorch_cuda"],
            extra_cflags=extra_cflags,
            build_directory=build_dir,
            is_python_module=False,
        )

        _launcher_inited = True


def build_humming_launcher_in_bg():
    if os.getenv("HUMMING_DISABLE_PARALLEL_BUILD", "0") == "1":
        return None
    cmd = "import humming.ops.utils; humming.ops.utils.init_humming_launcher()"
    env = os.environ.copy()
    env["HUMMING_DISABLE_PARALLEL_BUILD"] = "1"
    jit_utils.popen_and_reap(
        [sys.executable, "-c", cmd],
        env=env,
        stderr=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
    )


build_humming_launcher_in_bg()
